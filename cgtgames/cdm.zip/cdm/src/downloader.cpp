#include "downloader.h"

#include <curl/curl.h>

#include <chrono>
#include <cstdio>
#include <fstream>
#include <iomanip>
#include <iostream>
#include <mutex>
#include <string>
#include <thread>
#include <vector>

static std::mutex progress_mutex;

static size_t write_data(
    void* ptr,
    size_t size,
    size_t nmemb,
    void* stream
) {
    return std::fwrite(
        ptr,
        size,
        nmemb,
        static_cast<FILE*>(stream)
    );
}

static std::string get_filename(const std::string& url) {
    std::size_t slash = url.find_last_of('/');

    if (slash == std::string::npos || slash == url.length() - 1) {
        return "downloaded_file";
    }

    std::string filename = url.substr(slash + 1);

    std::size_t query = filename.find('?');

    if (query != std::string::npos) {
        filename.erase(query);
    }

    if (filename.empty()) {
        return "downloaded_file";
    }

    return filename;
}

static const char* http_status_text(long code) {
    switch (code) {
        case 200: return "OK";
        case 206: return "Partial Content";
        case 301: return "Moved Permanently";
        case 302: return "Found";
        case 304: return "Not Modified";
        case 400: return "Bad Request";
        case 401: return "Unauthorized";
        case 403: return "Forbidden";
        case 404: return "Not Found";
        case 405: return "Method Not Allowed";
        case 408: return "Request Timeout";
        case 429: return "Too Many Requests";
        case 500: return "Internal Server Error";
        case 501: return "Not Implemented";
        case 502: return "Bad Gateway";
        case 503: return "Service Unavailable";
        case 504: return "Gateway Timeout";
        default: return "Unknown HTTP Status";
    }
}

static bool check_http_status(CURL* curl) {
    long response_code = 0;

    CURLcode result = curl_easy_getinfo(
        curl,
        CURLINFO_RESPONSE_CODE,
        &response_code
    );

    if (result != CURLE_OK) {
        std::cerr << "CDM: could not determine HTTP status.\n";
        return false;
    }

    if (response_code >= 400) {
        std::cerr << "CDM: HTTP "
                  << response_code
                  << " "
                  << http_status_text(response_code)
                  << '\n';

        return false;
    }

    return true;
}

static bool get_file_size(
    const std::string& url,
    curl_off_t& size
) {
    CURL* curl = curl_easy_init();

    if (!curl) {
        return false;
    }

    curl_easy_setopt(curl, CURLOPT_URL, url.c_str());
    curl_easy_setopt(curl, CURLOPT_NOBODY, 1L);
    curl_easy_setopt(curl, CURLOPT_FOLLOWLOCATION, 1L);

    CURLcode result = curl_easy_perform(curl);

    if (result != CURLE_OK) {
        std::cerr << "CDM: connection failed: "
                  << curl_easy_strerror(result)
                  << '\n';

        curl_easy_cleanup(curl);
        return false;
    }

    if (!check_http_status(curl)) {
        curl_easy_cleanup(curl);
        return false;
    }

    result = curl_easy_getinfo(
        curl,
        CURLINFO_CONTENT_LENGTH_DOWNLOAD_T,
        &size
    );

    curl_easy_cleanup(curl);

    if (result != CURLE_OK || size <= 0) {
        std::cerr << "CDM: could not determine file size.\n";
        return false;
    }

    return true;
}

static std::string format_size(double bytes) {
    const char* units[] = {
        "B",
        "KB",
        "MB",
        "GB"
    };

    int unit = 0;

    while (bytes >= 1024.0 && unit < 3) {
        bytes /= 1024.0;
        ++unit;
    }

    std::ostringstream out;

    out << std::fixed
        << std::setprecision(unit == 0 ? 0 : 2)
        << bytes
        << ' '
        << units[unit];

    return out.str();
}

static std::string format_time(double seconds) {
    if (seconds < 0 || seconds > 8640000) {
        return "--:--";
    }

    int total = static_cast<int>(seconds);

    int hours = total / 3600;
    int minutes = (total % 3600) / 60;
    int secs = total % 60;

    std::ostringstream out;

    if (hours > 0) {
        out << std::setfill('0')
            << std::setw(2)
            << hours
            << ':';
    }

    out << std::setfill('0')
        << std::setw(2)
        << minutes
        << ':'
        << std::setw(2)
        << secs;

    return out.str();
}

struct ProgressData {
    curl_off_t start = 0;
    curl_off_t total = 0;
    std::string label;
    std::chrono::steady_clock::time_point begin;
    std::chrono::steady_clock::time_point last_update;
};

static int progress_callback(
    void* clientp,
    curl_off_t,
    curl_off_t now,
    curl_off_t,
    curl_off_t
) {
    ProgressData* data =
        static_cast<ProgressData*>(clientp);

    auto current =
        std::chrono::steady_clock::now();

    auto elapsed =
        std::chrono::duration<double>(
            current - data->begin
        ).count();

    auto since_update =
        std::chrono::duration<double>(
            current - data->last_update
        ).count();

    if (since_update < 0.15) {
        return 0;
    }

    data->last_update = current;

    double downloaded =
        static_cast<double>(now);

    double speed =
        elapsed > 0.0
            ? downloaded / elapsed
            : 0.0;

    double percent =
        data->total > 0
            ? (downloaded * 100.0) /
              static_cast<double>(data->total)
            : 0.0;

    double remaining =
        speed > 0.0
            ? (data->total - downloaded) / speed
            : 0.0;

    if (percent > 100.0) {
        percent = 100.0;
    }

    int bar_width = 25;

    int filled =
        static_cast<int>(
            (percent / 100.0) * bar_width
        );

    std::string bar;

    for (int i = 0; i < bar_width; ++i) {
        bar += (i < filled) ? '#' : '-';
    }

    std::lock_guard<std::mutex> lock(
        progress_mutex
    );

    std::cout
        << '\r'
        << data->label
        << " ["
        << bar
        << "] "
        << std::fixed
        << std::setprecision(1)
        << std::setw(5)
        << percent
        << "% "
        << std::setprecision(2)
        << format_size(speed)
        << "/s ETA "
        << format_time(remaining)
        << std::flush;

    return 0;
}

static bool download_single(
    const std::string& url,
    const std::string& filename,
    curl_off_t file_size
) {
    FILE* file =
        std::fopen(filename.c_str(), "wb");

    if (!file) {
        std::cerr
            << "CDM: could not create output file.\n";
        return false;
    }

    CURL* curl = curl_easy_init();

    if (!curl) {
        std::fclose(file);
        return false;
    }

    ProgressData progress;

    progress.total = file_size;
    progress.label = "CDM:";
    progress.begin =
        std::chrono::steady_clock::now();
    progress.last_update = progress.begin;

    curl_easy_setopt(
        curl,
        CURLOPT_URL,
        url.c_str()
    );

    curl_easy_setopt(
        curl,
        CURLOPT_WRITEFUNCTION,
        write_data
    );

    curl_easy_setopt(
        curl,
        CURLOPT_WRITEDATA,
        file
    );

    curl_easy_setopt(
        curl,
        CURLOPT_FOLLOWLOCATION,
        1L
    );

    curl_easy_setopt(
        curl,
        CURLOPT_NOPROGRESS,
        0L
    );

    curl_easy_setopt(
        curl,
        CURLOPT_XFERINFOFUNCTION,
        progress_callback
    );

    curl_easy_setopt(
        curl,
        CURLOPT_XFERINFODATA,
        &progress
    );

    CURLcode result =
        curl_easy_perform(curl);

    bool http_ok = false;

    if (result == CURLE_OK) {
        http_ok = check_http_status(curl);
    }
    else {
        std::cerr
            << "\nCDM: download failed: "
            << curl_easy_strerror(result)
            << '\n';
    }

    curl_easy_cleanup(curl);
    std::fclose(file);

    if (result != CURLE_OK || !http_ok) {
        std::remove(filename.c_str());
        return false;
    }

    std::cout << '\n';

    return true;
}

struct SharedProgress {
    std::mutex mutex;

    std::vector<curl_off_t> downloaded;
    std::vector<curl_off_t> totals;

    std::chrono::steady_clock::time_point begin;

    bool failed = false;
};

struct PartProgress {
    SharedProgress* shared;
    int index;
};

static int part_progress_callback(
    void* clientp,
    curl_off_t,
    curl_off_t now,
    curl_off_t,
    curl_off_t
) {
    PartProgress* progress =
        static_cast<PartProgress*>(clientp);

    SharedProgress* shared =
        progress->shared;

    {
        std::lock_guard<std::mutex> lock(
            shared->mutex
        );

        shared->downloaded[progress->index] =
            now;
    }

    auto current =
        std::chrono::steady_clock::now();

    double elapsed =
        std::chrono::duration<double>(
            current - shared->begin
        ).count();

    curl_off_t total_downloaded = 0;
    curl_off_t total_size = 0;

    {
        std::lock_guard<std::mutex> lock(
            shared->mutex
        );

        for (std::size_t i = 0;
             i < shared->downloaded.size();
             ++i) {
            total_downloaded +=
                shared->downloaded[i];

            total_size +=
                shared->totals[i];
        }
    }

    double percent =
        total_size > 0
            ? static_cast<double>(
                total_downloaded
              ) * 100.0 /
              static_cast<double>(
                total_size
              )
            : 0.0;

    double speed =
        elapsed > 0.0
            ? static_cast<double>(
                total_downloaded
              ) / elapsed
            : 0.0;

    double remaining =
        speed > 0.0
            ? static_cast<double>(
                total_size -
                total_downloaded
              ) / speed
            : 0.0;

    int bar_width = 25;

    int filled =
        static_cast<int>(
            percent / 100.0 * bar_width
        );

    if (filled > bar_width) {
        filled = bar_width;
    }

    std::string bar;

    for (int i = 0; i < bar_width; ++i) {
        bar += (i < filled) ? '#' : '-';
    }

    {
        std::lock_guard<std::mutex> lock(
            progress_mutex
        );

        std::cout
            << '\r'
            << "CDM:"
            << " ["
            << bar
            << "] "
            << std::fixed
            << std::setprecision(1)
            << std::setw(5)
            << percent
            << "% "
            << std::setprecision(2)
            << format_size(speed)
            << "/s ETA "
            << format_time(remaining)
            << "   "
            << std::flush;
    }

    return 0;
}

static bool download_part(
    const std::string& url,
    const std::string& part_name,
    curl_off_t start,
    curl_off_t end,
    int index,
    SharedProgress* shared
) {
    FILE* file =
        std::fopen(part_name.c_str(), "wb");

    if (!file) {
        return false;
    }

    CURL* curl = curl_easy_init();

    if (!curl) {
        std::fclose(file);
        return false;
    }

    std::string range =
        std::to_string(start)
        + "-"
        + std::to_string(end);

    PartProgress progress;

    progress.shared = shared;
    progress.index = index;

    curl_easy_setopt(
        curl,
        CURLOPT_URL,
        url.c_str()
    );

    curl_easy_setopt(
        curl,
        CURLOPT_WRITEFUNCTION,
        write_data
    );

    curl_easy_setopt(
        curl,
        CURLOPT_WRITEDATA,
        file
    );

    curl_easy_setopt(
        curl,
        CURLOPT_RANGE,
        range.c_str()
    );

    curl_easy_setopt(
        curl,
        CURLOPT_FOLLOWLOCATION,
        1L
    );

    curl_easy_setopt(
        curl,
        CURLOPT_NOPROGRESS,
        0L
    );

    curl_easy_setopt(
        curl,
        CURLOPT_XFERINFOFUNCTION,
        part_progress_callback
    );

    curl_easy_setopt(
        curl,
        CURLOPT_XFERINFODATA,
        &progress
    );

    CURLcode result =
        curl_easy_perform(curl);

    bool success = false;

    if (result == CURLE_OK) {
        long response_code = 0;

        curl_easy_getinfo(
            curl,
            CURLINFO_RESPONSE_CODE,
            &response_code
        );

        if (response_code == 206) {
            success = true;
        }
        else if (response_code >= 400) {
            std::lock_guard<std::mutex> lock(
                progress_mutex
            );

            std::cerr
                << "\nCDM: HTTP "
                << response_code
                << " "
                << http_status_text(response_code)
                << '\n';
        }
        else {
            std::lock_guard<std::mutex> lock(
                progress_mutex
            );

            std::cerr
                << "\nCDM: server did not return "
                   "partial content.\n";
        }
    }
    else {
        std::lock_guard<std::mutex> lock(
            progress_mutex
        );

        std::cerr
            << "\nCDM: part "
            << index
            << " failed: "
            << curl_easy_strerror(result)
            << '\n';
    }

    curl_easy_cleanup(curl);
    std::fclose(file);

    if (!success) {
        std::remove(part_name.c_str());

        std::lock_guard<std::mutex> lock(
            shared->mutex
        );

        shared->failed = true;
    }

    return success;
}

bool Downloader::download(
    const std::string& url,
    const std::string& requested_filename,
    int threads
) {
    std::string filename =
        requested_filename;

    if (filename.empty()) {
        filename = get_filename(url);
    }

    std::cout
        << "CDM: downloading "
        << url
        << '\n';

    std::cout
        << "CDM: output -> "
        << filename
        << '\n';

    std::cout
        << "CDM: threads -> "
        << threads
        << '\n';

    CURLcode init_result =
        curl_global_init(
            CURL_GLOBAL_DEFAULT
        );

    if (init_result != CURLE_OK) {
        std::cerr
            << "CDM: curl initialization failed.\n";
        return false;
    }

    curl_off_t file_size = 0;

    if (!get_file_size(url, file_size)) {
        curl_global_cleanup();
        return false;
    }

    std::cout
        << "CDM: size -> "
        << file_size
        << " bytes\n";

    if (threads <= 1 || file_size < threads) {
        bool result =
            download_single(
                url,
                filename,
                file_size
            );

        curl_global_cleanup();

        return result;
    }

    if (threads > 32) {
        threads = 32;
    }

    SharedProgress shared;

    shared.downloaded.resize(
        threads,
        0
    );

    shared.totals.resize(
        threads,
        0
    );

    shared.begin =
        std::chrono::steady_clock::now();

    std::vector<std::thread> workers;
    std::vector<std::string> parts;
    std::vector<bool> results(
        threads,
        false
    );

    curl_off_t part_size =
        file_size / threads;

    for (int i = 0; i < threads; ++i) {
        curl_off_t start =
            i * part_size;

        curl_off_t end;

        if (i == threads - 1) {
            end = file_size - 1;
        }
        else {
            end =
                start +
                part_size -
                1;
        }

        shared.totals[i] =
            end - start + 1;

        std::string part_name =
            filename +
            ".cdm_part_" +
            std::to_string(i);

        parts.push_back(part_name);

        workers.emplace_back(
            [&, i, start, end, part_name]() {
                results[i] =
                    download_part(
                        url,
                        part_name,
                        start,
                        end,
                        i,
                        &shared
                    );
            }
        );
    }

    for (auto& worker : workers) {
        worker.join();
    }

    if (shared.failed) {
        std::cerr
            << "\nCDM: one or more "
               "download parts failed.\n";

        for (const std::string& part : parts) {
            std::remove(part.c_str());
        }

        curl_global_cleanup();
        return false;
    }

    std::ofstream output(
        filename,
        std::ios::binary
    );

    if (!output) {
        std::cerr
            << "\nCDM: could not create "
               "output file.\n";

        for (const std::string& part : parts) {
            std::remove(part.c_str());
        }

        curl_global_cleanup();
        return false;
    }

    for (const std::string& part : parts) {
        std::ifstream input(
            part,
            std::ios::binary
        );

        if (!input) {
            output.close();

            std::remove(filename.c_str());

            for (const std::string& p : parts) {
                std::remove(p.c_str());
            }

            curl_global_cleanup();
            return false;
        }

        output << input.rdbuf();

        input.close();

        std::remove(part.c_str());
    }

    output.close();

    {
        std::lock_guard<std::mutex> lock(
            progress_mutex
        );

        std::cout
            << '\r'
            << "CDM: [#########################]"
            << " 100.0% "
            << '\n';
    }

    curl_global_cleanup();

    return true;
}
#include <iostream>
#include <string>

#include "downloader.h"

int main(int argc, char* argv[]) {
    std::cout << "CDM - CGT Download Manager\n";

    if (argc < 2) {
        std::cout << "Usage: cdm [options] <URL>\n";
        std::cout << "Options:\n";
        std::cout << "  -n <filename>   Output filename\n";
        std::cout << "  -t <threads>    Download threads\n";
        return 1;
    }

    std::string url;
    std::string filename;
    int threads = 1;

    for (int i = 1; i < argc; ++i) {
        std::string arg = argv[i];

        if (arg == "-n") {
            if (i + 1 >= argc) {
                std::cerr << "CDM: -n requires a filename.\n";
                return 1;
            }

            filename = argv[++i];
        }
        else if (arg == "-t") {
            if (i + 1 >= argc) {
                std::cerr << "CDM: -t requires a number.\n";
                return 1;
            }

            try {
                threads = std::stoi(argv[++i]);
            }
            catch (...) {
                std::cerr << "CDM: invalid thread count.\n";
                return 1;
            }

            if (threads < 1) {
                std::cerr << "CDM: thread count must be at least 1.\n";
                return 1;
            }
        }
        else if (!arg.empty() && arg[0] == '-') {
            std::cerr << "CDM: unknown option: " << arg << '\n';
            return 1;
        }
        else {
            if (!url.empty()) {
                std::cerr << "CDM: multiple URLs specified.\n";
                return 1;
            }

            url = arg;
        }
    }

    if (url.empty()) {
        std::cerr << "CDM: no URL specified.\n";
        return 1;
    }

    Downloader downloader;

    if (!downloader.download(url, filename, threads)) {
        std::cerr << "Download failed.\n";
        return 1;
    }

    std::cout << "Download complete.\n";
    return 0;
}
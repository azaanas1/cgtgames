@echo off
title CDM Compiler

echo ========================================
echo        CDM - CGT Download Manager
echo              Build System
echo ========================================
echo.

echo [1/2] Compiling CDM...

g++ src\main.cpp src\downloader.cpp ^
-Iinclude ^
-Llib ^
-lcurl ^
-o bin\cdm.exe

if errorlevel 1 (
    echo.
    echo [ERROR] Compilation failed.
    pause
    exit /b 1
)

echo.
echo [2/2] Build successful!
echo.
echo Output:
echo   bin\cdm.exe
echo.

dir bin\cdm.exe

echo.
echo ========================================
echo              BUILD COMPLETE
echo ========================================
pause
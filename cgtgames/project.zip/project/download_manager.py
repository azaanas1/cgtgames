import os
import sys
import time
import threading
import urllib.request
import shutil


BUFFER_SIZE = 96 * 1024


def format_size(size):
    return f"{size / (1024 * 1024):.2f} MB"


def print_progress(downloaded, total, start_time):
    elapsed = time.perf_counter() - start_time

    if elapsed > 0.05:
        speed = downloaded / elapsed
        speed_mb = speed / (1024 * 1024)
    else:
        speed = 0
        speed_mb = 0

    if total > 0:
        percent = (downloaded / total) * 100

        bar_length = 30
        filled_length = int(
            bar_length * downloaded // total
        )

        bar = (
            "#" * filled_length
            + "-" * (bar_length - filled_length)
        )

        if speed > 0:
            remaining = total - downloaded
            eta = remaining / speed
            eta_text = f"{eta:.1f}s"
        else:
            eta_text = "Calculating..."

        line = (
            f"[{bar}] {percent:.1f}% • "
            f"{speed_mb:.2f} MB/s • ETA: {eta_text}"
        )

    else:
        line = (
            f"Downloaded: {format_size(downloaded)} • "
            f"{speed_mb:.2f} MB/s"
        )

    print(
        f"\r{line:<100}",
        end="",
        flush=True
    )


def cleanup_parts_directory(part_directory):
    """
    Safely remove the temporary .adm_parts directory.
    Used after success, failure, or cancellation.
    """
    if not os.path.exists(part_directory):
        return

    try:
        shutil.rmtree(part_directory)
    except Exception as e:
        print(
            f"\n[WARNING] Could not clean up "
            f"temporary files: {e}"
        )


def download_single(
    url,
    destination,
    total_size=0,
    cancel_event=None
):
    req = urllib.request.Request(
        url,
        headers={"User-Agent": "Mozilla/5.0"}
    )

    bytes_downloaded = 0
    start_time = time.perf_counter()

    try:
        with urllib.request.urlopen(req) as response:
            with open(destination, "wb") as f:

                while True:

                    if (
                        cancel_event
                        and cancel_event.is_set()
                    ):
                        return False

                    chunk = response.read(BUFFER_SIZE)

                    if not chunk:
                        break

                    f.write(chunk)
                    bytes_downloaded += len(chunk)

                    print_progress(
                        bytes_downloaded,
                        total_size,
                        start_time
                    )

        return True

    except KeyboardInterrupt:

        if cancel_event:
            cancel_event.set()

        return False

    except Exception:
        return False


def get_file_info(url):
    req = urllib.request.Request(
        url,
        headers={"User-Agent": "Mozilla/5.0"}
    )

    with urllib.request.urlopen(req) as response:
        headers = response.headers

        content_length = headers.get("content-length")
        accept_ranges = headers.get(
            "accept-ranges",
            ""
        ).lower()

        total_size = 0

        if content_length:
            try:
                total_size = int(content_length)

            except ValueError:
                total_size = 0

        supports_ranges = (
            accept_ranges == "bytes"
        )

        return total_size, supports_ranges


def threaded_worker(
    url,
    part_path,
    start_byte,
    end_byte,
    progress,
    lock,
    cancel_event
):
    headers = {
        "User-Agent": "Mozilla/5.0",
        "Range": (
            f"bytes={start_byte}-{end_byte}"
        )
    }

    req = urllib.request.Request(
        url,
        headers=headers
    )

    try:
        with urllib.request.urlopen(req) as response:

            with open(part_path, "wb") as f:

                while True:

                    if cancel_event.is_set():
                        return

                    chunk = response.read(
                        BUFFER_SIZE
                    )

                    if not chunk:
                        break

                    f.write(chunk)

                    with lock:
                        progress["downloaded"] += len(chunk)

    except Exception as e:

        with lock:
            progress["error"] = e

        cancel_event.set()


def download_threaded(
    url,
    destination,
    total_size,
    thread_count
):
    print(f"Threads: {thread_count}")
    print(
        f"Buffer: "
        f"{BUFFER_SIZE // 1024} KB/thread"
    )

    part_directory = (
        destination + ".adm_parts"
    )

    os.makedirs(
        part_directory,
        exist_ok=True
    )

    cancel_event = threading.Event()
    lock = threading.Lock()

    progress = {
        "downloaded": 0,
        "error": None
    }

    threads = []

    start_time = time.perf_counter()

    try:

        base_size = (
            total_size // thread_count
        )

        remainder = (
            total_size % thread_count
        )

        current_start = 0

        # Start worker threads
        for i in range(thread_count):

            part_size = base_size

            if i < remainder:
                part_size += 1

            part_start = current_start

            part_end = (
                part_start
                + part_size
                - 1
            )

            part_path = os.path.join(
                part_directory,
                f"part_{i}"
            )

            thread = threading.Thread(
                target=threaded_worker,
                args=(
                    url,
                    part_path,
                    part_start,
                    part_end,
                    progress,
                    lock,
                    cancel_event
                )
            )

            thread.start()
            threads.append(thread)

            current_start = (
                part_end + 1
            )

        # Monitor workers
        while any(
            thread.is_alive()
            for thread in threads
        ):

            if cancel_event.is_set():
                break

            with lock:
                downloaded = (
                    progress["downloaded"]
                )

                error = (
                    progress["error"]
                )

            print_progress(
                downloaded,
                total_size,
                start_time
            )

            if error:
                cancel_event.set()
                break

            time.sleep(0.1)

        # Always wait for every worker.
        # This MUST happen before cleanup.
        for thread in threads:
            thread.join()

        with lock:
            error = progress["error"]

        if error:

            print(
                f"\n[ERROR] Download failed: "
                f"{error}"
            )

            return False

        if cancel_event.is_set():

            print(
                "\n[CANCELLED] "
                "Download cancelled."
            )

            return False

        # Final progress
        print_progress(
            total_size,
            total_size,
            start_time
        )

        print()

        # Combine all parts
        with open(
            destination,
            "wb"
        ) as output:

            for i in range(
                thread_count
            ):

                part_path = os.path.join(
                    part_directory,
                    f"part_{i}"
                )

                with open(
                    part_path,
                    "rb"
                ) as part:

                    while True:

                        chunk = part.read(
                            BUFFER_SIZE
                        )

                        if not chunk:
                            break

                        output.write(chunk)

        return True

    except KeyboardInterrupt:

        cancel_event.set()

        print(
            "\n[CANCELLED] "
            "Download cancelled."
        )

        # Wait for all workers
        # before deleting their files.
        for thread in threads:
            thread.join()

        return False

    except Exception as e:

        cancel_event.set()

        print(
            f"\n[ERROR] Download failed: {e}"
        )

        # Wait for all workers.
        for thread in threads:
            thread.join()

        return False

    finally:

        # This executes on:
        # SUCCESS
        # ERROR
        # Ctrl+C
        #
        # All worker threads have
        # already been joined.
        cleanup_parts_directory(
            part_directory
        )


def download_file(
    url,
    destination,
    thread_count=1
):
    print(
        f"Connecting to: {url}..."
    )

    try:

        total_size, supports_ranges = (
            get_file_info(url)
        )

        if total_size > 0:

            print(
                f"File Size: "
                f"{format_size(total_size)}"
            )

        else:

            print(
                "File Size: Unknown "
                "(Streaming data...)"
            )

        # Multi-threading requires:
        # 1. Known file size
        # 2. HTTP Range support
        if (
            thread_count > 1
            and total_size > 0
            and supports_ranges
        ):

            print(
                "Server supports "
                "HTTP Range requests."
            )

            print(
                "Starting multi-threaded "
                "download..."
            )

            success = download_threaded(
                url,
                destination,
                total_size,
                thread_count
            )

        else:

            if thread_count > 1:

                print(
                    "Server does not support "
                    "multi-threaded ranges. "
                    "Using single-thread mode."
                )

            success = download_single(
                url,
                destination,
                total_size
            )

        if success:

            print(
                "[SUCCESS] "
                "Download completed!"
            )

    except KeyboardInterrupt:

        print(
            "\n[CANCELLED] "
            "Download cancelled."
        )

    except Exception as e:

        print(
            f"\n[ERROR] "
            f"Download failed: {e}"
        )


def print_usage():

    executable_name = os.path.basename(
        sys.argv[0]
    )

    print(
        f"Usage:\n"
        f"  {executable_name} "
        f"[options] URL\n\n"
        f"Options:\n"
        f"  -n filename    "
        f"Custom output filename\n"
        f"  -O folder      "
        f"Output directory\n"
        f"  -t threads     "
        f"Number of download threads\n"
        f"  Ctrl+C         "
        f"Cancel download\n"
    )


if __name__ == "__main__":

    if len(sys.argv) < 2:

        print_usage()
        sys.exit(1)

    args = sys.argv[1:]

    custom_name = None
    output_directory = None
    thread_count = 1
    target_url = None

    i = 0

    try:

        while i < len(args):

            argument = args[i]

            if argument == "-n":

                if i + 1 >= len(args):

                    print(
                        "[ERROR] "
                        "-n requires a filename."
                    )

                    sys.exit(1)

                custom_name = args[i + 1]
                i += 2

            elif argument == "-O":

                if i + 1 >= len(args):

                    print(
                        "[ERROR] "
                        "-O requires a directory."
                    )

                    sys.exit(1)

                output_directory = (
                    args[i + 1]
                )

                i += 2

            elif argument == "-t":

                if i + 1 >= len(args):

                    print(
                        "[ERROR] "
                        "-t requires a thread count."
                    )

                    sys.exit(1)

                try:

                    thread_count = int(
                        args[i + 1]
                    )

                except ValueError:

                    print(
                        "[ERROR] "
                        "Thread count must "
                        "be a number."
                    )

                    sys.exit(1)

                if thread_count < 1:

                    print(
                        "[ERROR] "
                        "Thread count must "
                        "be at least 1."
                    )

                    sys.exit(1)

                i += 2

            elif argument.startswith("-"):

                print(
                    f"[ERROR] "
                    f"Unknown option: "
                    f"{argument}"
                )

                print_usage()
                sys.exit(1)

            else:

                if target_url is not None:

                    print(
                        "[ERROR] "
                        "Multiple URLs "
                        "are not supported."
                    )

                    sys.exit(1)

                target_url = argument
                i += 1

        if target_url is None:

            print(
                "[ERROR] "
                "No URL specified."
            )

            print_usage()
            sys.exit(1)

        if not target_url.startswith(
            ("http://", "https://")
        ):

            target_url = (
                "https://" + target_url
            )

        if custom_name:

            filename = custom_name

        else:

            filename = (
                target_url.split("/")[-1]
                or "index.html"
            )

            if (
                filename.endswith(".com")
                or filename.endswith(".org")
                or filename.endswith(".net")
            ):

                filename = "index.html"

        if output_directory:

            os.makedirs(
                output_directory,
                exist_ok=True
            )

            destination = os.path.join(
                output_directory,
                filename
            )

        else:

            destination = filename

        download_file(
            target_url,
            destination,
            thread_count
        )

    except KeyboardInterrupt:

        print(
            "\n[CANCELLED] "
            "Download cancelled."
        )
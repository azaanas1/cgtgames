#ifndef STRUCTURES_H
#define STRUCTURES_H

#include "raylib.h"
#include <string>
#include <vector>

// --- Game State System ---
enum GameState { STATE_DEALERSHIP, STATE_DRIVING };

// --- Car Customization Configurations ---
struct CarBrand {
    std::string name;
    float maxSpeed;
    float acceleration;
    Vector3 dimensions; // Width, Height, Length
};

struct CarColor {
    std::string name;
    Color bodyColor;
};

// --- Infinite World Objects ---
enum PropType { PROP_TREE, PROP_ROCK };

struct Prop {
    PropType type;
    Vector3 position;
    Color color;
    Vector3 scale;
};

struct Chunk {
    Vector2 coord;
    std::vector<Prop> props;
};

// Custom comparator to allow using Vector2 as a key in std::map
struct Vector2Compare {
    bool operator()(const Vector2& a, const Vector2& b) const {
        if (a.x != b.x) return a.x < b.x;
        return a.y < b.y;
    }
};

#endif

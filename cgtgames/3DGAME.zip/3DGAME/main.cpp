#include "raylib.h"
#include "raymath.h"
#include "rlgl.h"
#include "structures.h"
#include <map>
#include <set>
#include <cstdlib>
#include <cmath>

const float CHUNK_SIZE = 50.0f;
const int RENDER_DISTANCE = 3; // Safely scaled up due to optimization

std::vector<Prop> GeneratePropsForChunk(int cx, int cz) {
    std::vector<Prop> props;
    if (cx == 0 && cz == 0) return props;

    // Use a localized deterministic pseudo-random formula instead of resetting global srand
    unsigned int seed = cx * 12345 + cz * 67890;
    auto localRand = [&seed]() {
        seed = seed * 1103515245 + 12345;
        return (unsigned int)(seed / 65536) % 32768;
    };

    int numProps = (localRand() % 4) + 2;
    for (int i = 0; i < numProps; i++) {
        Prop p; 
        p.type = (localRand() % 2 == 0) ? PROP_TREE : PROP_ROCK;
        p.position = { 
            (cx * CHUNK_SIZE) + (float)(localRand() % 40 - 20), 
            0.5f, 
            (cz * CHUNK_SIZE) + (float)(localRand() % 40 - 20) 
        };
        
        if (p.type == PROP_TREE) { 
            p.position.y = 1.0f; 
            p.color = LIME; 
            p.scale = {3.0f, 1.5f, 3.0f}; 
        } else { 
            p.color = GRAY; 
            p.scale = {2.0f, 1.0f, 2.0f}; 
        }
        props.push_back(p);
    }
    return props;
}

void DrawCubeRotated(Vector3 pos, Vector3 sz, float rot, Color c) {
    rlPushMatrix(); 
        rlTranslatef(pos.x, pos.y, pos.z); 
        rlRotatef(rot, 0, 1, 0); 
        DrawCube({0,0,0}, sz.x, sz.y, sz.z, c); 
    rlPopMatrix();
}

// Fixed visual seating offset bugs by tracking parent space origins locally
void DrawDetailedCar(Vector3 pos, Vector3 sz, float rot, Color bodyColor) {
    rlPushMatrix();
        rlTranslatef(pos.x, pos.y, pos.z);
        rlRotatef(rot, 0, 1, 0);
        // Base chassis
        DrawCube({0,0,0}, sz.x, sz.y, sz.z, bodyColor);
        // Left & Right Seats drawn correctly inside the relative space
        DrawCube({-0.22f, sz.y / 2.0f + 0.1f, -0.05f}, 0.35f, 0.8f, 0.25f, BLACK);
        DrawCube({ 0.22f, sz.y / 2.0f + 0.1f, -0.05f}, 0.35f, 0.8f, 0.25f, BLACK);
    rlPopMatrix();
}

int main() {
    InitWindow(1280, 720, "Dealership & Game Loop"); 
    SetTargetFPS(60);
    
    GameState state = STATE_DEALERSHIP;
    std::vector<CarBrand> brands = { 
        {"Hypercar", 50.0f, 30.0f, {2.4f, 0.5f, 5.0f}}, 
        {"Muscle", 35.0f, 22.0f, {2.2f, 0.7f, 4.6f}}, 
        {"Compact", 22.0f, 14.0f, {1.9f, 0.8f, 3.6f}} 
    };
    std::vector<CarColor> colors = { 
        {"Red", RED}, {"Blue", BLUE}, {"Black", BLACK}, {"Yellow", GOLD} 
    };
    
    int selB = 0, selC = 0;
    Vector3 carPos = { 0.0f, 0.3f, 0.0f };
    float carRot = 0.0f, speed = 0.0f, timeOfDay = 0.0f, showroomSpin = 0.0f;
    
    Camera3D cam = { {0,6,-15}, {0,0,0}, {0,1,0}, 60.0f, CAMERA_PERSPECTIVE };
    Camera3D showCam = { {0,3.5f,6}, {0,0.5f,0}, {0,1,0}, 45.0f, CAMERA_PERSPECTIVE };
    std::map<Vector2, Chunk, Vector2Compare> chunks;

    while (!WindowShouldClose()) {
        float dt = GetFrameTime();
        
        if (state == STATE_DEALERSHIP) {
            showroomSpin += 30.0f * dt;
            if (IsKeyPressed(KEY_UP)) selB = (selB - 1 + brands.size()) % brands.size();
            if (IsKeyPressed(KEY_DOWN)) selB = (selB + 1) % brands.size();
            if (IsKeyPressed(KEY_LEFT)) selC = (selC - 1 + colors.size()) % colors.size();
            if (IsKeyPressed(KEY_RIGHT)) selC = (selC + 1) % colors.size();
            if (IsKeyPressed(KEY_ENTER)) { 
                carPos = {0, brands[selB].dimensions.y / 2.0f, 0}; 
                carRot = 0; speed = 0; state = STATE_DRIVING; 
            }
        } else {
            if (IsKeyPressed(KEY_ESCAPE)) state = STATE_DEALERSHIP;
            timeOfDay += dt * 0.05f; if (timeOfDay > 1.0f) timeOfDay = 0.0f;
            
            if (IsKeyDown(KEY_W)) speed += brands[selB].acceleration * dt;
            else if (IsKeyDown(KEY_S)) speed -= brands[selB].acceleration * dt;
            else { 
                if (speed > 0) speed = fmaxf(0, speed - 6 * dt); 
                else speed = fminf(0, speed + 6 * dt); 
            }
            if (IsKeyDown(KEY_SPACE)) { 
                if (speed > 0) speed = fmaxf(0, speed - 40 * dt); 
                else speed = fminf(0, speed + 40 * dt); 
            }
            
            speed = Clamp(speed, -brands[selB].maxSpeed / 2.0f, brands[selB].maxSpeed);
            if (speed != 0.0f) {
                float dm = (speed > 0) ? 1.0f : -1.0f;
                if (IsKeyDown(KEY_A)) carRot += 75.0f * dt * dm;
                if (IsKeyDown(KEY_D)) carRot -= 75.0f * dt * dm;
            }
            
            float rad = carRot * DEG2RAD;
            carPos.x += sinf(rad) * speed * dt; 
            carPos.z += cosf(rad) * speed * dt;
            
            cam.position = Vector3Add(carPos, Vector3Scale({-sinf(rad), 0, -cosf(rad)}, 15.0f)); 
            cam.position.y = carPos.y + 6.0f; 
            cam.target = carPos;
            
            int ccX = (int)floorf((carPos.x + CHUNK_SIZE / 2.0f) / CHUNK_SIZE);
            int ccZ = (int)floorf((carPos.z + CHUNK_SIZE / 2.0f) / CHUNK_SIZE);
            
            std::set<Vector2, Vector2Compare> visible;
            for (int x = ccX - RENDER_DISTANCE; x <= ccX + RENDER_DISTANCE; x++) {
                for (int z = ccZ - RENDER_DISTANCE; z <= ccZ + RENDER_DISTANCE; z++) {
                    Vector2 coord = {(float)x, (float)z}; 
                    visible.insert(coord);
                    if (chunks.find(coord) == chunks.end()) { 
                        Chunk c; c.coord = coord; c.props = GeneratePropsForChunk(x, z); 
                        chunks[coord] = c; 
                    }
                }
            }
            for (auto it = chunks.begin(); it != chunks.end();) { 
                if (visible.find(it->first) == visible.end()) it = chunks.erase(it); 
                else ++it; 
            }
        }

        BeginDrawing();
            if (state == STATE_DEALERSHIP) {
                ClearBackground({25, 25, 35, 255});
                BeginMode3D(showCam);
                    DrawPlane({0,0,0}, {6,6}, DARKGRAY); 
                    DrawGrid(20, 1.0f);
                    DrawDetailedCar({0, 0, 0}, brands[selB].dimensions, showroomSpin, colors[selC].bodyColor);
                EndMode3D();

                DrawRectangle(40, 40, 450, 250, ColorAlpha(BLACK, 0.7f));
                DrawText("CAR DEALERSHIP", 60, 60, 24, GOLD);
                DrawText("BRANDS (UP / DOWN):", 60, 110, 16, LIGHTGRAY);
                for (size_t i = 0; i < brands.size(); i++) {
                    DrawText(brands[i].name.c_str(), 70, 135 + (i * 22), 18, (i == (size_t)selB) ? LIME : WHITE);
                }
                DrawText("COLOR (LEFT / RIGHT):", 60, 220, 16, LIGHTGRAY);
                DrawText(TextFormat("< %s >", colors[selC].name.c_str()), 70, 245, 18, SKYBLUE);
                DrawText("PRESS ENTER TO TEST DRIVE", 60, 310, 20, ORANGE);
            } else {
                float intensity = (sinf(timeOfDay * PI * 2.0f) + 1.0f) / 2.0f;
                ClearBackground({(unsigned char)(135*intensity), (unsigned char)(206*intensity), (unsigned char)(250*intensity), 255});
                
                BeginMode3D(cam);
                    for (const auto& pair : chunks) {
                        DrawPlane({pair.first.x * CHUNK_SIZE, 0, pair.first.y * CHUNK_SIZE}, {CHUNK_SIZE, CHUNK_SIZE}, GREEN);
                        for (const auto& prop : pair.second.props) {
                            if (prop.type == PROP_TREE) { 
                                DrawCube({prop.position.x, 1, prop.position.z}, 0.6f, 2, 0.6f, BROWN); 
                                DrawSphere({prop.position.x, 2, prop.position.z}, 1.5f, LIME); 
                            } else {
                                DrawCubeV(prop.position, prop.scale, prop.color);
                            }
                        }
                    }
                    DrawDetailedCar(carPos, brands[selB].dimensions, carRot, colors[selC].bodyColor);
                EndMode3D();
                
                DrawRectangle(10, 10, 480, 110, ColorAlpha(BLACK, 0.5f));
                // Optimized text allocations via built-in TextFormat
                DrawText(TextFormat("Model: %s (%s)", brands[selB].name.c_str(), colors[selC].name.c_str()), 20, 45, 18, LIGHTGRAY);
                DrawText(TextFormat("Speed: %d MPH", (int)std::abs(speed)), 20, 68, 18, LIME);
            }
        EndDrawing();
    }
    CloseWindow();
    return 0;
}
